﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelMa
{
    public partial class Reservation : Form
    {
        public Reservation()
        {
            InitializeComponent();
        }

        Room room = new Room();
        Reserv reserv = new Reserv();



        private void Reservation_Load(object sender, EventArgs e)
        {
            comboBoxRoomType.DataSource = room.roomTypeList();
            comboBoxRoomType.DisplayMember = "label";
            comboBoxRoomType.ValueMember = "type_id";

            int type = Convert.ToInt32(comboBoxRoomType.SelectedValue.ToString());
            comboBoxRoomNumber.DataSource = room.roomByType(type);
            comboBoxRoomNumber.DisplayMember = "Room_Number";
            comboBoxRoomNumber.ValueMember = "Room_Number";

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBoxClientID.Text = "";
            //textBoxReservID.Text = "";
            comboBoxRoomType.SelectedIndex = 0;
            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker2.Value = DateTime.Now;

        }

        private void comboBoxRoomType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int type = Convert.ToInt32(comboBoxRoomType.SelectedValue.ToString());
                comboBoxRoomNumber.DataSource = room.roomByType(type);
                comboBoxRoomNumber.DisplayMember = "Room_Number";
                comboBoxRoomNumber.ValueMember = "Room_Number";

            }
            catch(Exception)
            {

            }


        }

        private void buttonAddRoom_Click(object sender, EventArgs e)
        {
            try
            {
                int clientID = Convert.ToInt32(textBoxClientID.Text);
                int roomNumber = Convert.ToInt32(comboBoxRoomNumber.SelectedValue);
                DateTime dateIn = dateTimePicker1.Value;
                DateTime dateOut = dateTimePicker2.Value;

                if(dateIn < DateTime.Now)
                {
                    MessageBox.Show("The Date In Must Be = or > To today date", "invalid date In", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if(dateOut < dateIn)
                {
                    MessageBox.Show("The Date Out Must Be = or > to date in", "invalid date Out", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (reserv.addReservation(roomNumber, clientID, dateIn, dateOut))
                    {
                        room.setRoomTFreeoNo(roomNumber);
                        MessageBox.Show("New Reservation Added", "Add Reservation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Reservation NOT Added", "Add Reservation", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Add Reservation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }
    }
}


//ALTER TABLE rooms ADD CONSTRAINT fk_type_id FOREIGN KEY (Room_type) REFERENCES room_type(type_id) on UPDATE CASCADE on DELETE CASCADE;
//ALTER TABLE reservations ADD CONSTRAINT fk_room_number FOREIGN KEY (roomNumber) REFERENCES rooms(Room_Number) on UPDATE CASCADE on DELETE CASCADE
//ALTER TABLE reservations ADD CONSTRAINT fk_client_id FOREIGN KEY (clientid) REFERENCES clients(id) on UPDATE CASCADE on DELETE CASCADE;