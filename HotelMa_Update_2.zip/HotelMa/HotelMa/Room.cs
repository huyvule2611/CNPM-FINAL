﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
namespace HotelMa
{
    class Room
    {
        CONNECT conn = new CONNECT();
        public DataTable roomTypeList()
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `room_type`", conn.getConnection());
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();
            adapter.SelectCommand = command;
            adapter.Fill(table);


            return table;
        }


        public DataTable roomByType(int type)
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `rooms` WHERE `room_type`= @typ and free='Yes'" , conn.getConnection());
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();

            command.Parameters.Add("@typ", MySqlDbType.Int32).Value = type;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            return table;

        }
        //public bool setRoomTFreeoNo(int number)
        //{
            //MySqlCommand command = new MySqlCommand("UPDATE `rooms` SET `free`= 'NO' WHERE `Room_Number` = @num", conn.getConnection());
            //MySqlDataAdapter adapter = new MySqlDataAdapter();
            //DataTable table = new DataTable();

            //command.Parameters.Add("@num", MySqlDbType.Int32).Value = number;

            

            //if(command.ExecuteNonQuery() == 1)
            //{
                //conn.openConnection();
                //return true;
            //}
            //else
            //{
                //conn.openConnection();
                //return false;
            //}

            
        //}
        public bool addRoom(int num,int type,String phone, String free)
        {
            MySqlCommand command = new MySqlCommand();
            String insertQuery = "INSERT INTO `rooms`(`Room_Number`, `Room_type`, `Phone`, `free`) VALUES (@num,@type,@phn,@free)";
            command.CommandText = insertQuery;
            command.Connection = conn.getConnection();
            //
            command.Parameters.Add("@num", MySqlDbType.Int32).Value = num;
            command.Parameters.Add("@type", MySqlDbType.Int32).Value = type;
            command.Parameters.Add("@phn", MySqlDbType.VarChar).Value = phone;
            command.Parameters.Add("@free", MySqlDbType.VarChar).Value = free;

            conn.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                conn.closeConnection();
                return true;
            }
            else
            {
                conn.closeConnection();
                return false;
            }

        }
        public DataTable getRoom()
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `rooms`", conn.getConnection());
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();
            adapter.SelectCommand = command;
            adapter.Fill(table);

            return table;
        }
        public bool editRoom(int num, int type, String phone, String free)
        {
            MySqlCommand command = new MySqlCommand();
            String editQuery = "UPDATE `rooms` SET `Room_type`=@type,`Phone`=@phn,`free`=@free WHERE `Room_Number` =@num";
            command.CommandText = editQuery;
            command.Connection = conn.getConnection();
            //
            command.Parameters.Add("@num", MySqlDbType.Int32).Value = num;
            command.Parameters.Add("@type", MySqlDbType.Int32).Value = type;            
            command.Parameters.Add("@phn", MySqlDbType.VarChar).Value = phone;
            command.Parameters.Add("@free", MySqlDbType.VarChar).Value = free;


            conn.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                conn.closeConnection();
                return true;
            }
            else
            {
                conn.closeConnection();
                return false;
            }

        }
        public bool removeRoom(int num)
        {
            MySqlCommand command = new MySqlCommand();
            String removeQuery = "DELETE FROM `rooms` WHERE `Room_Number`=@num";
            command.CommandText = removeQuery;
            command.Connection = conn.getConnection();
            //@cid
            command.Parameters.Add("@num", MySqlDbType.Int32).Value = num;
            conn.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                conn.closeConnection();
                return true;
            }
            else
            {
                conn.closeConnection();
                return false;
            }
        }
    }

}
