﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelMa
{
    public partial class RoomsManage : Form
    {
        public RoomsManage()
        {
            InitializeComponent();
        }
        Room room = new Room();
        private void RoomsManage_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = room.roomTypeList();
            comboBox1.DisplayMember = "label";
            comboBox1.ValueMember = "type_id";
            dataGridView1.DataSource = room.getRoom();


        }

        private void buttonAddRoom_Click(object sender, EventArgs e)
        {
            int number = Convert.ToInt32(textBoxNumber.Text);
            int type = Convert.ToInt32(comboBox1.SelectedValue.ToString());
            string phone = textBoxPhone.Text;
            String free = "";
            if (radioButtonYES.Checked)
            {
                free = "Yes";
            }
            else if (radioButtonNO.Checked)
            {
                free = "no";
            }
            if (room.addRoom(number,type,phone,free))
            {
                dataGridView1.DataSource = room.getRoom();
                MessageBox.Show("add successs", "add room", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("add failed", "add room", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxNumber.Text = "";
            textBoxPhone.Text = "";
            comboBox1.SelectedIndex = 0;
            radioButtonNO.Checked = true;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBoxNumber.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            comboBox1.SelectedValue = dataGridView1.CurrentRow.Cells[1].Value;
            textBoxPhone.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            String free = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            if(free.Equals("yes"))
            {
                radioButtonYES.Checked = true;
            }
            else if (free.Equals("no"))
            {
                radioButtonNO.Checked = true;
            }
        }

        private void buttonEditRoom_Click(object sender, EventArgs e)
        {
            int num;
            int type = Convert.ToInt32(comboBox1.SelectedValue.ToString());
            String phone = textBoxPhone.Text;
            String free = "";
            try
            {
                num = Convert.ToInt32(textBoxNumber.Text);
                if (radioButtonYES.Checked)
                {
                    free = "Yes";
                }
                else if (radioButtonNO.Checked)
                {
                    free = "no";
                }

                if (room.editRoom(num, type, phone, free))
                {
                    dataGridView1.DataSource = room.getRoom();
                    MessageBox.Show("edited", "edit room", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Failed", "edit room", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error - No Data", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            


        }

        private void buttonRemoveRoom_Click(object sender, EventArgs e)
        {
            
            try
            {
                int num = Convert.ToInt32(textBoxNumber.Text);
                if (room.removeRoom(num))
                {
                    dataGridView1.DataSource = room.getRoom();
                    MessageBox.Show("removed", "edit room", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Failed", "edit room", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"Error - No data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

